mix deps.get
mix compile
mix test --trace
