defmodule CartTest do
  use ExUnit.Case
  doctest Cart

  test "step 1: adds five products" do
    # given an empty cart...
    cart = %Cart{}

    # and a product...
    product = %Product{name: "Dove Soap", price: 39.99}

    # add five products
    actual =
      cart
      |> Cart.add(product, 5)

    num_products =
      actual
      |> Cart.get_num_products()

    total_cost =
      actual
      |> Cart.get_total_cost()

    # verify number of products and total cost
    assert num_products == 5
    assert total_cost == 199.95
  end
end
