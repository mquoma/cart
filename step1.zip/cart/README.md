# Cart

Equal Experts Tech Interview Solution Step 1
Version number: e5ce2b40e077ee165c0a6b7598317089354c8922

## Requirements

Elixir (https://elixir-lang.org/install.html)

## Instructions

Option 1:

Give execute permissions to the following build script and run it
```
chmod +x build.sh
. build.sh
```

which should execute the following mix commands (Options 2):

```
mix deps.get
mix compile
mix test --trace
```
