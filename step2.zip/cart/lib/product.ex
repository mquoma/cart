defmodule Product do
  @moduledoc """
    Product
    A simple product struct
  """
  defstruct [:name, :price]
end
