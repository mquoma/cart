defmodule CartTest do
  use ExUnit.Case
  doctest Cart

  test "step 2: adds five and then three products" do
    # given an empty cart...
    cart = %Cart{}

    # and a product...
    product = %Product{name: "Dove Soap", price: 39.99}

    # add five products
    actual =
      cart
      |> Cart.add(product, 5)
      |> Cart.add(product, 3)

    num_products =
      actual
      |> Cart.get_num_products()

    total_cost =
      actual
      |> Cart.get_total_cost()

    # verify number of products and total cost
    assert num_products == 8
    assert total_cost == 319.92
  end
end
